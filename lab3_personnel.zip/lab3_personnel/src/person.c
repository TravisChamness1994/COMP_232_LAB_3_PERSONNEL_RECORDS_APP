#include "person.h"

LIST *head = NULL, *tail = NULL;

void inputPersonalData(PERSON *person)
{
    // TODO implement the function
    // or check out part 9 of the c tutorial ;)
}

void addPersonalDataToDatabase(PERSON *person)
{
    // TODO Implement the function
}

void displayDatabase()
{
    // TODO Implement the function
}

void displayPerson(PERSON *person)
{
    // TODO Implement the function
    // hmmmm seems familiar....
}

PERSON *findPersonInDatabase(char *name)
{
    // TODO Implement the function

    return NULL; // if not found
}

void removePersonFromDatabase(char *name)
{
    // TODO Implement the function
}

void clearDatabase()
{
    // TODO Implement the function
}
